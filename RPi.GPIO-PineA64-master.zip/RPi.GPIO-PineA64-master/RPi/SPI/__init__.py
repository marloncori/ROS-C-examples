"""
"""

from RPi._SPI import *

VERSION = '0.6.2'
