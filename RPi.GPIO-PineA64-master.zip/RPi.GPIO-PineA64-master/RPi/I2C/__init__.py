"""
"""

from RPi._I2C import *

VERSION = '0.6.2'
