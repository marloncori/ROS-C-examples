# RPi.GPIO-PineA64

This is a RPi.GPIO module for Pine A64/A64+ board.

- GPIO input and output
- GPIO interrupts(callbacks when events occur on input gpios) Not Implemented yet!!!
- Software PWM

Install this package by executing:
````
sudo python setup.py install
````
